from django.contrib import admin
from .models import Post ,Post_2
# Register your models here.

@admin.register(Post)

class PostAdmin(admin.ModelAdmin):
    list_display=(
        'title',
        "slug",
        'author',
        'publish',
        'status',
        "body",
    )

    list_filter=(

        'title',
        'status',
        'title'
    )

    search_fields=(
        'title',
        "status",
        "title"
    )
    prepopulated_fields = {'slug': ('title',)}
    raw_id_fields = ('author',)
    date_hierarchy = 'publish'


@admin.register(Post_2)
class PostAdmin3(admin.ModelAdmin):
    list_display=(
        "body","name")
   # list_filter=(
   #     'name',
    #    "email",
     #   "neckname",
    #)
   # search_fields=(
    #    "name",
    #    "email",
    #)

