from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from .models import todo
# Create your views here.

def home(request):
   #return  HttpResponse("hello")
   todos=todo.objects.all().order_by("time")
   return render(request,"index.html",{
       "todos":todos
   })

@csrf_exempt
def todo_add(request):
    date=timezone.now()
    content=request.POST["content"]
    print(content)
    create=todo.objects.create(
        time=date,text=content
    )

    return HttpResponseRedirect('/')

@csrf_exempt
def delet(request,todo_id):
    todo.objects.get(id=todo_id).delete()
    return HttpResponseRedirect("/")

def index(request):
    return HttpResponse("Home page")

def detail(request,question_id):
    return HttpResponse("you are lookig for %s"%question_id)
def results(request,question_id):
    return HttpResponse("result number %s" % question_id)

def vote(request,question_id):
    return HttpResponse('you are on vote %s'%question_id)