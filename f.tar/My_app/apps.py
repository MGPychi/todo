from django.apps import AppConfig


class MyAppConfig(AppConfig):
    name = 'My_app'
